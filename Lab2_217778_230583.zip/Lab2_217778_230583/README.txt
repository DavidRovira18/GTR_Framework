Júlia Coll 203583 julia.coll03@estudiant.upf.edu
David Rovira 217778 david.rovira01@estudiant.upf.edu

En esta práctica hemos programado Deferred Rendering, PBR, SSAO con oriented hemispheres y gamma y degamma, con la posibilidad de usar distintos Tonemappers. 

Deferred rendering se puede activar desde el GUI, seleccionando rendering mode DEFERRED. 
Una vez estás en modo deferred, puedes seleccionar dos tipos de Iluminación, Phong y PBR, desde la selección Available Shaders. (Capturas Deferred_Phong y Deferred_PBR)

En el menú rendering parameters, permite utilizar los normalmaps o mostrar los shadowmaps (Captura Deferred_PBR_Normalmaps). 
En el menú deferred parameters, encontrarás checkbox para mostrar los Gbuffers (que se actualizan si hay un resize de la pantalla), la Global Position, y activar o desactivar SSAO (captura Deferred_PBR_NOSSAO).
Tambien encontrarás sliders para modificar los parametros del SSAO y para visualizar su fbo (captura SSAO_fbo). 
Además, si activamos "dist2cam" o "opacity" desde el menú render priority, aparecera en el menú deferred parameters un checkbox para activar y desactivar el dithering (captura Deferred_dithering). En el caso de no tener los objetos ordenados por opacidad y distancia, dithering se usa por defecto.

Por otra parte, estamos haciendo HDR rendering. (captura HDR_Render) 

Finalmente, damos la opción desde el GUI, de usar diferentes tonemappers. (Capturas No_Tonemapper, Tonemapper, Uncharted_Tonemapper)



